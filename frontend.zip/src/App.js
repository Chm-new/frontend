import Basic from './components/Basic';



function App() {
 
  return (
    <div className="App">
      사랑
      <Basic />

    </div>
  );
}

export default App;
